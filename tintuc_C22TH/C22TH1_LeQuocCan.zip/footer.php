    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="col-md-12">
                <p>Copyright &copy; Your Website 2014</p>
            </div>
        </div>
    </footer>
    <!-- end Footer -->